Wheel for DC motor by Anything_3D on Thingiverse: https://www.thingiverse.com/thing:2804854

Summary:
This wheel is for yellow direct current motors with gears http://s.click.aliexpress.com/e/eL5mzmE